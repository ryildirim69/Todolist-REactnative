const Colors={
    defaultGreenColor:'#5BED53',
    defaultGreyColor:'#313030',
    defaultDarkColor:'#161616',
    defaultTitleColor:'white'
}
export default Colors;