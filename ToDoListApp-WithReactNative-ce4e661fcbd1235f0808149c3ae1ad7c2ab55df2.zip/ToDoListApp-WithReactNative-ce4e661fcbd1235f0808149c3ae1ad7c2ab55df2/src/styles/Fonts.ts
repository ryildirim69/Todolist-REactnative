const Fonts={
    defaultRegularFontFamily:'nunito-regular'
}
export default Fonts;